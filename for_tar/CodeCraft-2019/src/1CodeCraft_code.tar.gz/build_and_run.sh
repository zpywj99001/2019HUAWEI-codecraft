#!/bin/bash
cd CodeCraft-2019
python src/CodeCraft-2019.py config/car.txt config/road.txt config/cross.txt config/answer.txt